﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace LrsColinAssembler {
	class DebugInfo {
		readonly short[]							Regs;
		readonly Interpreter.CondCode				CC;
		public List<(short addr , ushort length)>	RamChanges;

//---------------------------------------------------------------------------------------

		public DebugInfo(short[] regs, Interpreter.CondCode cc) {
			Regs = new short[16];
			Array.Copy(regs, Regs, 16);
			CC = cc;
			RamChanges = new List<(short addr, ushort length)>();
		}

//---------------------------------------------------------------------------------------

		public void ShowChanged(short[]			regs,
						  Interpreter.CondCode  cc) {
			bool HasChanges = false;
			string sep = ", ";
			for (int i = 0; i < 16; i++) {
				if (Regs[i] != regs[i]) {
					Console.Write($"{sep}R{i} -> {regs[i]}(0x{regs[i]:X1})");
					HasChanges = true;
				}
			}
			if (CC != cc) { 
				Console.Write($"{sep}CC -> {cc}");
				HasChanges = true;
			}

			foreach (var (addr, length) in RamChanges) {
				Console.Write($"{sep}@{addr:X4} -> ");
				for (int i = 0; i < length; i++) {
					Console.Write($"{Interpreter.Ram[i]:X2}");
					HasChanges = true;
				}

			}
			if (HasChanges) { Console.WriteLine(); }
		}

//---------------------------------------------------------------------------------------

		internal void ShowOpcode(ushort pc, byte[] ram, Dictionary<string, ushort> symtab) {
			string label = GetLabel(pc, symtab);
			if (label.Length > 0) { Console.WriteLine($"At {label}"); }
			byte opcode = ram[pc];
			string mnemonic = GetOpcodeMnemonic(opcode, ram, pc);
			string instruction = "";
			if (mnemonic.StartsWith("$")) { instruction = $"{opcode:X2}"; }
			else {
				int len = 2 * (1 + ((opcode & 0xC0) >> 6));
				for (int i = 0; i < len; i++) {
					instruction += $"{ram[pc + i]:X2}";	// Note: Bad way to concatenate
				}
			}
			Console.Write($"Trace:  {pc:X4}: {instruction} ({mnemonic})");
		}

//---------------------------------------------------------------------------------------

		private string GetLabel(ushort pc, Dictionary<string, ushort> symtab) {
			// Yeah, we could do this more efficiently, but for our toy programs,
			// I won't bother
			foreach (string key in symtab.Keys) {
				ushort addr = symtab[key];
				if (addr == pc) { return key; }
			}
			return "";
		}

//---------------------------------------------------------------------------------------

		private string GetOpcodeMnemonic(byte opcode, byte[] ram, ushort pc) {
			foreach (string key in Assembler.OpcodeTable.Keys) {
				var entry = Assembler.OpcodeTable[key];
				if (entry.Op == opcode) {
					if (opcode != 0x47) { return key; }
					byte mask = (byte)((ram[pc + 1] & 0xf0) >> 4);
					foreach (string bkey in Assembler.BranchMasks.Keys) {
						if (Assembler.BranchMasks[bkey] == mask) { return bkey; }
					}
					throw new Exception($"can't find branch mask {mask:X2}");
				}
			}
			throw new Exception($"*** Error finding mnemonic for opcode {opcode:X2}");
		}

//---------------------------------------------------------------------------------------

		public static void CopyToClipboard(string s) {
			// pbcopy < file.txt
			// type file.txt | clip
			string temp = Path.GetTempFileName();
			File.WriteAllText(temp, s);
			string script = Path.GetTempFileName() + ".bat";
			if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) {
				File.WriteAllText(script, $"type {temp} | clip");
			} else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX)) {
				// TODO: May have to run chmod +755 (or whatever) first
				File.WriteAllText(script, $"pbcopy < {temp}");
			} else {
				// Presumably some flavor of *nix. Don't know how to do that.
				return; // Just ignore
			}
			var proc = Process.Start(script);
			proc.WaitForExit();
			File.Delete(temp);
			File.Delete(script);
		}
	}

#if false  // No longer used

//---------------------------------------------------------------------------------------

		// Tracing routine
		private void DumpRegs() {
			for (int i = 0; i < 16; i++) {
				string msg = $"R{i}".PadRight(4);
				msg += $"{Registers[i]:X4}";
				msg += $" ({Registers[i]:N0})".PadRight(8);
				Console.Write(msg);
				if ((i > 0) && ((i % 4) == 3)) { Console.WriteLine(); }
			}
		}
#endif
}