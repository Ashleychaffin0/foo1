using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;	// For GUID class
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

using Microsoft.Zune.Configuration;
using Microsoft.Zune.ErrorMapperApi;
using Microsoft.Zune.Messaging;
using Microsoft.Zune.Playlist;
using Microsoft.Zune.Service;
using Microsoft.Zune.Shell;
using Microsoft.Zune.Subscription;
using Microsoft.Zune.Util;

using Microsoft.Iris;
using Microsoft.Iris.Accessibility;
using Microsoft.Iris.OS;
using Microsoft.Iris.RenderAPI;

using MicrosoftZuneInterop;
using MicrosoftZuneLibrary;
using MicrosoftZunePlayback;


using LRS.Zune.Classes;

// TODO:
//	1)	Generate ZuneTypeFactory class
//	2)	Generate public static EQueryType EnumVal = EQueryType.eQueryTypeAllVideos;	
//		for all classes


// See Tom Fuller's entry at
// http://soapitstop.com/blogs/fleamarket/archive/2008/03/03/read-the-zune-collection-in-net-from-zune-s-own-api.aspx

// Note: A compilation album that got a DisplayArtist right is 
//	C:\$ Zune Master\Various Artists\16 Most Requested Songs of the 1950's, Vol. 1\3 Jezebel.wma
//		 But be careful. The DisplayArtist is "Frankie Lane" (sic).

// Once we get the CE Compact database opened (we hope), to get a list of all the tables, use
//		SELECT * FROM INFORMATION_SCHEMA.TABLES
// or perhaps
//		select name from sys.objects where type = 'U'

// Schema mappings: Type | enum
//	string	|	SchemaMap.kiIndex_DisplayArtist
//	int		|	SchemaMap.kiIndex_AlbumID

namespace Zune2 {
	public partial class LRSZune2 : Form {

		// const string ZuneDir = @"C:\Program Files\Zune";
		MicrosoftZuneLibrary.ZuneLibrary zl;

		Dictionary<SchemaMap, Type> SchemaToType = new Dictionary<SchemaMap, Type>();

//---------------------------------------------------------------------------------------

		public LRSZune2() {
			InitializeComponent();

			zl = new ZuneLibrary();
			int i1 = zl.Initialize();
			if (i1 != 0) {
				string	msg = string.Format("Could not initialize the Zune Library, rc = {0:X8}", i1);
				MessageBox.Show(msg);
				return;
			}

			SetupSchemaToType();

			// zl.ExecuteQueryHelper(...);

		}

//---------------------------------------------------------------------------------------

		private void SetupSchemaToType() {
			SchemaToType[SchemaMap.kiIndex_DisplayArtist] = typeof(string);
			SchemaToType[SchemaMap.kiIndex_AlbumID]		  = typeof(int);
			SchemaToType[SchemaMap.kiIndex_AlbumIDAlbumArtist] = typeof(string);
		}

//---------------------------------------------------------------------------------------

		private void btnShowArtists_Click(object sender, EventArgs e) {
#if false
			zl.Phase2Initialization();
			ZuneLibraryCDRecorder rec =  zl.GetRecorder();
			ZuneQueryList zql = zl.QueryDatabase(EQueryType.eQueryTypeAllAlbumArtists, 1, EQuerySortType.eQuerySortOrderAscending, 0, null);
#endif

			ShowArtists();
		}

//---------------------------------------------------------------------------------------

		private void ShowArtists() {
			MicrosoftZuneLibrary.ZuneQueryList artists;
			artists = zl.QueryDatabase(EQueryType.eQueryTypeAllAlbumArtists, 0, EQuerySortType.eQuerySortOrderAscending,
				(uint)SchemaMap.kiIndex_DisplayArtist, null);
			for (uint i = 0; i < artists.Count; i++) {
				object o = artists.GetFieldValue(i, typeof(string), (uint)SchemaMap.kiIndex_DisplayArtist);
				// o = artists.GetFieldValue(i, typeof(uint), (uint)SchemaMap.kiIndex_DisplayArtistCount);
				Console.WriteLine("Artist[{0}] = '{1}'", i, o);
			}
		}

//---------------------------------------------------------------------------------------

		private void btnShowAlbums_Click(object sender, EventArgs e) {
			MicrosoftZuneLibrary.ZuneQueryList	albums;
			SchemaMap smt;				// smt = SchemaMap Type
			// smt = SchemaMap.kiIndex_Title;	
			// smt = SchemaMap.kiIndex_AlbumID;
			smt = SchemaMap.kiIndex_AlbumIDAlbumArtist;
			albums = zl.QueryDatabase(EQueryType.eQueryTypeAllAlbums, 0, EQuerySortType.eQuerySortOrderAscending,
				(uint)smt, null);
			ZuneQueryItem it = new ZuneQueryItem(albums, 0);
			for (uint i = 0; i < albums.Count; i++) {
				Type type = SchemaToType[smt];
				// object o = albums.GetFieldValue(i, type, (uint)smt);
				object o = albums.GetFieldValue(i, typeof(int), (uint)SchemaMap.kiIndex_AlbumID);
				object oo = albums.GetFieldValue(i, typeof(string), (uint)SchemaMap.kiIndex_DisplayArtist);
				// o = artists.GetFieldValue(i, typeof(uint), (uint)SchemaMap.kiIndex_DisplayArtistCount);
				Console.WriteLine("Albums[{0}] = '{1}'", i, o);

				ZuneQueryList trks = zl.GetTracksByAlbum(0, (int)o, EQuerySortType.eQuerySortOrderAscending, (uint)SchemaMap.kiIndex_CPTrackID);
				for (uint j = 0; j < trks.Count; j++) {
					// object otrk = trks.GetFieldValue(j, typeof(string), (uint)SchemaMap.kiIndex_DisplayArtist);
					object otrk = trks.GetFieldValue(j, typeof(string), (uint)SchemaMap.kiIndex_Title);
					Console.WriteLine("Track : {0}", otrk);
				}
			}
		}

//---------------------------------------------------------------------------------------

		private void btnGetKnownFolders_Click(object sender, EventArgs e) {
			string []	Music;
			string []	Videos;
			string []	Pictures;
			string []	Podcasts;
			string		RipFolder;

			zl.GetKnownFolders(out Music, out Videos, out Pictures, out Podcasts, out RipFolder);
		}

//---------------------------------------------------------------------------------------


		// TODO: Put all failed smt enum names into a List<>, and print them out at the end
		//		 of the EQType. Ditto for Exceptions.
		private void btnTryAllQueryTypes_Click(object sender, EventArgs e) {
			MicrosoftZuneLibrary.ZuneQueryList ZQList;
			int	nEQTypes = 0;
			var BadCombinations = new List<SchemaMap>();
			foreach (var EQType in Enum.GetValues(typeof(EQueryType))) {
				Console.WriteLine("\n\n{0,3}: EQTYpe = {1} / {2}", ++nEQTypes, EQType, (int)EQType);
				int		nSmts = 0;
				BadCombinations.Clear();
				foreach (var smt in Enum.GetValues(typeof(SchemaMap))) {
					// Console.WriteLine("\tSMT = {0} / {1}", smt, (int)smt);
					try {
						using (ZQList = zl.QueryDatabase((EQueryType)EQType, 0, EQuerySortType.eQuerySortOrderAscending,
							// Note: It seems like the SortAtom affects only (duh) the order in which
							//		 the ZQList is returned. It can even be 0.
							0 /*(uint)(int)smt*/ , null)) {
							if (ZQList == null) {
								BadCombinations.Add((SchemaMap)smt);
								// Console.WriteLine("\t\t{0} *** Failed", smt);
							} else {
								++nSmts;
								ProcessFields(nSmts, (EQueryType)EQType, (SchemaMap)smt, ZQList);
							}
						}
					} catch (Exception ex) {
						string	msg = string.Format("\t***** Exception thrown for EQType/SchemaMap = {0}/{1} - Exception = {2}",
							EQType, smt, ex.ToString());
						Console.WriteLine("{0}", msg);
					}
				}
				foreach (var item in BadCombinations) {
					Console.WriteLine("\t\t*** Bad Schema {0}", item);
				}
			}
			MessageBox.Show("Done");
		}

//---------------------------------------------------------------------------------------

		private void ProcessFields(int n, EQueryType EQType, SchemaMap smt, ZuneQueryList ZQList) {
			Console.WriteLine("\t{0,3}: smt = {1} worked, Count={2}", n, smt, ZQList.Count);
			if (ZQList.Count == 0) {
				return;
			}

			object o;
			// Here's where it could get really intensive. At the moment, I have roughly
			// 7000 tracks in the database. I don't want to through all 374 Schema values
			// for each track. (That's 7000 * 374 = 2.6 million combinations). So we'll
			// just go through the Schema values on ZQList[0]. This should be enough
			// to tell us what's going on.
			uint	ix = 0;				// Index into ZQList
			foreach (var smt2 in Enum.GetValues(typeof(SchemaMap))) {
				// Result type string
				o = ZQList.GetFieldValue(ix, typeof(string), (uint)(int)smt2);
				if (o != null) {
					Console.WriteLine("\t\tSchema = {0}, string->'{1}'", smt2, o);
					continue;
				}
				// Result type int
				o = ZQList.GetFieldValue(ix, typeof(int), (uint)(int)smt2);
				if (o != null) {
					Console.WriteLine("\t\tSchema = {0}, int->'{1}'", smt2, o);
					continue;
				}
				// Result type uint
				o = ZQList.GetFieldValue(ix, typeof(uint), (uint)(int)smt2);
				if (o != null) {
					Console.WriteLine("\t\tSchema = {0}, uint->'{1}'", smt2, o);
					continue;
				}
				// Result type DateTime
				o = ZQList.GetFieldValue(ix, typeof(DateTime), (uint)(int)smt2);
				if (o != null) {
					Console.WriteLine("\t\tSchema = {0}, DateTime->'{1}'", smt2, o);
					continue;
				}
				// Result type GUID
				o = ZQList.GetFieldValue(ix, typeof(Guid), (uint)(int)smt2);
				if (o != null) {
					Console.WriteLine("\t\tSchema = {0}, Guid->'{1}'", smt2, o);
					continue;
				}
			}
		}

//---------------------------------------------------------------------------------------

		private void btnQueryTypeAndSchemae_Click(object sender, EventArgs e) {
			var QandS = GetQueriesAndSchemae(zl);

			PrintQueriesAndSchemae(QandS);

			MessageBox.Show("Done");
		}

//---------------------------------------------------------------------------------------

		private Dictionary<EQueryType, List<SchemaMapAndType>> GetQueriesAndSchemae(ZuneLibrary zl) {
			MicrosoftZuneLibrary.ZuneQueryList ZQList;
			Dictionary<EQueryType, List<SchemaMapAndType>> QueriesAndSchemae;
			QueriesAndSchemae = new Dictionary<EQueryType, List<SchemaMapAndType>>();
			List<SchemaMapAndType> Schemae;
			foreach (var EQType in Enum.GetValues(typeof(EQueryType))) {
				Schemae = new List<SchemaMapAndType>();
				try {
					// Note: SortAtom is just 0 in QueryDatabase call
					using (ZQList = zl.QueryDatabase((EQueryType)EQType, 0, EQuerySortType.eQuerySortOrderAscending, 0, null)) {
						if ((ZQList != null) && (ZQList.Count > 0)) {
							Schemae = GetSchemaeForEqueryType(ZQList, EQType);
						}
					}
				} catch (Exception) {
					// Ignore exception and continue
				}
				QueriesAndSchemae[(EQueryType)EQType] = Schemae;
			}
			return QueriesAndSchemae;
		}

//---------------------------------------------------------------------------------------

		private void PrintQueriesAndSchemae(Dictionary<EQueryType, List<SchemaMapAndType>> QueriesAndSchemae) {
			foreach (EQueryType eqt in QueriesAndSchemae.Keys) {
				Console.WriteLine("\n\nQuery Type {0} / {1}", eqt, (int)eqt);
				foreach (var SmtAndType in QueriesAndSchemae[eqt]) {
					Console.WriteLine("\t\tSchema {0} / {1} \t-> {2}", 
						SmtAndType.smt, (int)SmtAndType.smt, SmtAndType.type);
				}
			}
		}

//---------------------------------------------------------------------------------------

		private List<SchemaMapAndType> GetSchemaeForEqueryType(ZuneQueryList ZQList, object EQType) {
			List<SchemaMapAndType> Schemae = new List<SchemaMapAndType>();
			uint	usmt;		// // smt = SchemaMap Type
			uint	ix = 0;
			Type	t;
			foreach (var smt in Enum.GetValues(typeof(SchemaMap))) {
				usmt = (uint)(int)smt;
				t = FieldType(ZQList, usmt, ix);
				if (t != null) {
					Schemae.Add(new SchemaMapAndType((SchemaMap)smt, t));
				}
			}
			return Schemae;
		}

//---------------------------------------------------------------------------------------

		private Type FieldType(ZuneQueryList ZQList, uint usmt, uint ix) {
			// AFAICT, the Zune software uses SQL Server Compact Edition (or possibly an
			// earlier version). It supports only a limited number of managed data types
			// and these are what we check for below.

			// Note: Opening the .sdf file in Sql Server Management Studio 2005 shows
			//		 that the database is SQL Server Compact Edition version 3.0.5300.0

			// Again, according to SSMS, the types it supports are
			//	bigint, binary, bit, datetime, float, image, int, money, nchar, ntext
			//	numeric, nvarchar, real, smallint, tinyint, uniqueidentifier, varbinary

			// See http://technet.microsoft.com/en-us/library/ms174642.aspx
			object o;

			// Some fields show up as int's, since they're enums. But we may know
			// better. So do some special checking first.

			if (usmt == (uint)SchemaMap.kiIndex_MediaType) {
				return typeof(EMediaTypes);
			}

			// End of special checking

			o = ZQList.GetFieldValue(ix, typeof(int), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(string), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(DateTime), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(Guid), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(bool), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(byte []), usmt);	// varbinary. Also Unicode?
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(byte), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(decimal), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(double), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(System.Drawing.Image), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(short), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(int), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(ushort), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(long), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(ulong), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(float), usmt);
			if (o != null) return o.GetType();

			// Dunno if these are possible, but let's try
			o = ZQList.GetFieldValue(ix, typeof(string []), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(int []), usmt);
			if (o != null) return o.GetType();

			o = ZQList.GetFieldValue(ix, typeof(byte [,]), usmt);
			if (o != null) return o.GetType();
			
			return null;
		}

//---------------------------------------------------------------------------------------

		private void btnDumpFirst10_Click(object sender, EventArgs e) {
			var	QandS = GetQueriesAndSchemae(zl);
			const int	nMax = 200;
			Cursor = Cursors.WaitCursor;
			// Using default sorting
			SchemaMap	SortOrder = (SchemaMap)0;	// Override later, maybe
			object	o;
			foreach (var EQType in QandS.Keys) {
#if true
				if (EQType != EQueryType.eQueryTypeAllGenres) {
					// SortOrder = SchemaMap.kiIndex_DateAdded;
					// SortOrder = SchemaMap.kiIndex_AlbumID;
					// SortOrder = SchemaMap.kiIndex_DisplayArtist;
					// continue;
				}
#endif
#if false
				zl.Dispose();
				zl = new ZuneLibrary();
				zl.Initialize();
#endif
				Console.WriteLine("\n\n--------------------------------\n\n");
				Console.WriteLine("Query Type {0} / {1}", EQType, (int)EQType);
				Console.Error.WriteLine("Query Type {0} / {1}", EQType, (int)EQType);
				using (ZuneQueryList ZQList = zl.QueryDatabase(EQType, 0, 
							EQuerySortType.eQuerySortOrderAscending, (uint)SortOrder, null)) {
					if (ZQList == null) {
						Console.WriteLine("\t******** Query returned null ********");
						continue;
					}
					Console.WriteLine("Count = {0}", ZQList.Count);
					int nRecs = Math.Min(ZQList.Count, nMax);
					try {
						for (int n = 0; n < nRecs; n++) {
							Console.WriteLine("\t----------------- Element {0}", n);
							foreach (var SmtAndType in QandS[EQType]) {
								Console.Write("\t\t{0} \t-> {1} -- ",
									SmtAndType.smt, SmtAndType.type);
#if false
								using (ZuneQueryItem zItem = new ZuneQueryItem(ZQList, n)) {
									o = zItem.GetFieldValue(SmtAndType.type, (uint)SmtAndType.smt);
									if (o == null) {
										Console.WriteLine("Uh-oh");
										continue;
									}
								}
#else
								o = ZQList.GetFieldValue((uint)n, SmtAndType.type, (uint)SmtAndType.smt);
								if (o == null) {
									Console.WriteLine("?Uh-oh?");
									continue;
								}
#endif
								if (SmtAndType.type == typeof(System.Collections.ArrayList)) {
									foreach (var elem in (ArrayList)o) {
										Console.WriteLine("\t\t\t{0}", elem);
									}
								} else {
									Console.WriteLine("\t\t\t{0}", o);
								}
							}
						}
					} catch (Exception ex) {
						Console.WriteLine("Exception: {0}", ex.ToString());
					}
				}
			}
			Cursor = Cursors.Default;
			MessageBox.Show("Done");
		}

//---------------------------------------------------------------------------------------

		private void btnSaveQueriesAndSchemae_Click(object sender, EventArgs e) {
			var QandS = GetQueriesAndSchemae(zl);
			// This is way cool!
			XDocument xd = new XDocument(
				new XElement("QueryTypes",
					from key in QandS.Keys
					select new XElement("QueryType", 
						new XAttribute("qtype", key),
						// new XElement("SchemaMapAndType",
							from smt in QandS[key]
							select new XElement("SchemaMap", smt.smt, 
										new XAttribute("type", smt.type)
					))));
			xd.Save("QueriesAndSchemae.xml");
		}

//---------------------------------------------------------------------------------------

		private void btnGenerateClasses_Click(object sender, EventArgs e) {
			const string EnumValName = "EnumVal";

			XDocument xd = XDocument.Load("QueriesAndSchemae.xml");

			StreamWriter	wtr = new StreamWriter("LRSZuneClasses.cs");

			wtr.WriteLine("// Copyright (c) 2008 by Larry Smith\n");
			wtr.WriteLine("using System;");
			wtr.WriteLine("using System.Collections;\t\t// For ArrayList");
			wtr.WriteLine("using System.Collections.Generic;");
			wtr.WriteLine();
			wtr.WriteLine("using MicrosoftZuneLibrary;");
			wtr.WriteLine();

			wtr.WriteLine("namespace LRS.Zune.Classes {");

			GenerateZuneTypeFactoryCode(wtr, EnumValName, xd.Root.Elements());

			string	ClassName = null;
			string	FieldName;
			StringBuilder	sb = new StringBuilder();
			string	sep = "//---------------------------------------------------------------------------------------";
			foreach (var elem in xd.Root.Elements()) {
				sb.Length = 0;			// Clear
				ClassName = elem.Attribute("qtype").Value;
				wtr.WriteLine("\n{0}\n{0}\n{0}\n{0}\n{0}\n", sep);
				wtr.WriteLine("\tpublic class {0} {{", ClassName);
				wtr.WriteLine("\t\tpublic static EQueryType {0} = EQueryType.{1};\n", EnumValName, ClassName);
				sb.AppendFormat("\n{0}\n\n\t\tpublic {1}(ZuneQueryList ZQList, uint n) {{\n", sep, ClassName);
				sb.Append("\t\t\tobject\to;\n\n");
				// Generate Fields
				foreach (var smt in elem.Elements()) {			
					FieldName = smt.Value;
					if (FieldName.StartsWith("kiIndex_")) {
						FieldName = FieldName.Substring(8);
					}
					string type = MapTypeToCSharp(smt.Attribute("type").Value);
					wtr.WriteLine("\t\tpublic {0}\t{1};", type, FieldName);
					sb.AppendFormat("\t\t\to = ZQList.GetFieldValue(n, typeof({0}), (uint)SchemaMap.{1}); {2} = ({0})(o ?? default({0}));\n", 
						type.Replace("\t", ""), smt.Value, FieldName);
				}
				sb.AppendFormat("\t\t}}\t\t// {0} ctor", ClassName);
				// Generate ctor
				wtr.WriteLine(sb.ToString());
				// Console.WriteLine("\n{0}\n", sep);
				// End class
				wtr.WriteLine("\t}}\t\t// {0} class\n", ClassName);
			}

			wtr.WriteLine("}");		// Namespace end
			wtr.Close();

			MessageBox.Show("TODO: Put this back into Dictionary form");
		}

//---------------------------------------------------------------------------------------

		private void GenerateZuneTypeFactoryCode(StreamWriter wtr, string EnumValName, IEnumerable<XElement> elems) {
			string s = string.Format(@"{0}public static class ZuneTypeFactory {{

		const string EnumValName = ""{1}"";", "\t", EnumValName);
			wtr.WriteLine(s);

			s = @"
//---------------------------------------------------------------------------------------

		public static IEnumerable<T> GetZuneItems<T>(ZuneLibrary zl) where T : class {
			Type	t = typeof(T);
			EQueryType type = (EQueryType)t.GetField(EnumValName).GetValue(t);
			using (ZuneQueryList zql = zl.QueryDatabase(type, 0,
				EQuerySortType.eQuerySortOrderAscending, 0, null)) {
				if (zql == null) {
					yield break;
				}
				for (uint i = 0; i < zql.Count; i++) {
					yield return (T)ZuneTypeFactory.Create<T>(zql, i);
				}
				yield break;
			}
		}";
			wtr.WriteLine(s);

			s=@"
//---------------------------------------------------------------------------------------
		
		public static object Create<T>(ZuneQueryList zql, uint i) where T : class  {";
			StringBuilder	sb = new StringBuilder(s);

			sb.Append("\n			Type t = typeof(T);\n");
			foreach (var elem in elems) {
				string	name = elem.Attribute("qtype").Value;
				sb.AppendFormat("\t\t\tif (t == typeof({0})) return new {0}(zql, i);\n", name);
			}

#if false
			
			if (t == typeof(eQueryTypeAllTracks))
				return new eQueryTypeAllTracks(zql, i);
#endif

			wtr.WriteLine(sb.ToString());

			wtr.WriteLine("\t\t\treturn null;");
			wtr.WriteLine("\t\t}");		// Close off method
			wtr.WriteLine("\t}");		// Close off class
		}

#if false
//---------------------------------------------------------------------------------------

		public static IEnumerable<T> xxGetZuneItems<T>(ZuneLibrary zl) where T : class {
			Type	t = typeof(T);
			EQueryType type = (EQueryType)t.GetField(EnumValName).GetValue(t);
			using (ZuneQueryList zql = zl.QueryDatabase(type, 0,
				EQuerySortType.eQuerySortOrderAscending, 0, null)) {
				if (zql == null) {
					yield break;
				}
				for (uint i = 0; i < zql.Count; i++) {
					// yield return new T(zql, i);
					yield return (T)ZuneTypeFactory.Create<T>(zql, i);
				}
				yield break;
			}
		}

//---------------------------------------------------------------------------------------
		
		public static object xxCreate<T>(ZuneQueryList zql, uint i) where T : class  {
		}
#endif

//---------------------------------------------------------------------------------------

		private string MapTypeToCSharp(string s) {
			return MapTypeToCSharp(s, true);
		}

//---------------------------------------------------------------------------------------

		private string MapTypeToCSharp(string s, bool bUseTab) {
			switch (s) {
			case "System.Int32":
				// When we're pumping out XML, we don't necessarily want tab
				// characters (they'll get translated to "int&#x9").
				if (bUseTab)
					return "int\t";
				else
					return "int";
			case "System.String":
				return "string";
			case "System.DateTime":
				return "DateTime";
			case "System.UInt64":
				return "ulong";
			case "System.Collections.ArrayList":
				return "ArrayList";
			// For some strange reason, 
			default:
				return s;
			}
		}

//---------------------------------------------------------------------------------------

		private void btnGetAlbumsViaClasses_Click(object sender, EventArgs e) {
			using (ZuneQueryList zql = zl.QueryDatabase(EQueryType.eQueryTypeAllAlbums, 0,
				EQuerySortType.eQuerySortOrderAscending, 0, null)) {
				if (zql == null) {
					MessageBox.Show("Unable to process Albums");
					return;
				}

				StreamWriter wtr = new StreamWriter("LRSZune_Albums.txt");

				var Albums = new List<eQueryTypeAllAlbums>(zql.Count);
				for (uint i = 0; i < zql.Count; i++) {
					Albums.Add(new eQueryTypeAllAlbums(zql, i));
				}
				int	n = 0;
				foreach (var album in Albums) {
					wtr.WriteLine();
					DumpObj(wtr, album);
				}
				wtr.Close();
			}
		}

//---------------------------------------------------------------------------------------

		private void DumpObj(StreamWriter wtr, object o) {
			Type t = o.GetType();
			var flds = from field in t.GetFields()
							 select field;
			string sep = "";
			foreach (var f in flds) {
				wtr.WriteLine("{0}{1} = {2}", sep, f.Name, t.GetField(f.Name).GetValue(o));
				sep = "\t";
			}
		}

//---------------------------------------------------------------------------------------

		private void btnFoo_Click(object sender, EventArgs e) {
			// EListType
			// EMediaStateType
			// EMediaCategories
			// EQueryTypeView
			var pb = new QueryPropertyBag(); 
			using (ZuneQueryList zql = zl.QueryDatabase(EQueryType.eQueryTypeAllAlbums, 0,
				EQuerySortType.eQuerySortOrderAscending, 0, pb)) {
				Type t = pb.GetType();
				MethodInfo mi = t.GetMethod("GetIQueryPropertyBag");
				System.Reflection.Pointer p = (System.Reflection.Pointer)mi.Invoke(pb, null);
				int		DumpNBytes = 2048;
				unsafe {
					GC.Collect();		// Minimize object movement in what follows
					// Note: To really minimize data movement, copy the data to a buffer,
					//		 then format that. TODO:
					byte *pp = (byte *)Pointer.Unbox(p);
					DumpBytePtr(pp, DumpNBytes, 32);
					Console.WriteLine();
					uint *pu = (uint *)pp;
					DumpBytePtr((byte *)pu[2], DumpNBytes, 32);
				}
				Console.WriteLine("\nDone");
				Console.WriteLine(zql);
			}
		}

//---------------------------------------------------------------------------------------

		unsafe void DumpBytePtr(byte* p, int nBytes, int ColumnWidth) {
			byte *q = p;
			for (int nRow = 0; nRow < nBytes; nRow += ColumnWidth, q += ColumnWidth) {
				int width = ColumnWidth;		// TODO:
				// IntPtr doesn't implement IFormattable, so it's always formatted
				// as a simple numeric (base 10) string. So to get it into hex, we
				// have to dance around a bit.
				string sAddr = (new  IntPtr((void*)q)).ToString();
				uint addr = uint.Parse(sAddr);
				Console.Write("{0,8:X}: ", addr);
				for (int i = 0; i < width; i++) {
					Console.Write("{0,02:X} ", q[i]);
				}
				Console.Write("  *");
				for (int i = 0; i < width; i++) {
					char c;
					if ((q[i] >= 0x20) && (q[i] < 0x7f))
						c = Convert.ToChar(q[i]);
					else
						c = '.';
					Console.Write("{0,2} ", c);
				}
				Console.WriteLine("*");
			}
		}

//---------------------------------------------------------------------------------------

		private void btnGetArtistsViaClasses_Click(object sender, EventArgs e) {
			using (ZuneQueryList zql = zl.QueryDatabase(EQueryType.eQueryTypeAllAlbumArtists, 0,
				EQuerySortType.eQuerySortOrderAscending, 0, null)) {
				if (zql == null) {
					MessageBox.Show("Unable to process Artists");
					return; 
				}

				StreamWriter wtr = new StreamWriter("LRSZune_Artists.txt");

				var Artists = new List<eQueryTypeAllAlbumArtists>(zql.Count);
				for (uint i = 0; i < zql.Count; i++) {
					Artists.Add(new eQueryTypeAllAlbumArtists(zql, i));
				}
				foreach (var artist in Artists) {
					wtr.WriteLine();
					DumpObj(wtr, artist);
				}
				wtr.Close();
			}
		}

//---------------------------------------------------------------------------------------

		private void btnGetTracksViaClasses_Click(object sender, EventArgs e) {
			using (ZuneQueryList zql = zl.QueryDatabase(EQueryType.eQueryTypeAllTracks, 0,
				EQuerySortType.eQuerySortOrderAscending, 0, null)) {
				if (zql == null) {
					MessageBox.Show("Unable to process Tracks");
					return; 
				}

				StreamWriter wtr = new StreamWriter("LRSZune_Tracks.txt");

				var Tracks = new List<eQueryTypeAllTracks>(zql.Count);
				for (uint i = 0; i < zql.Count; i++) {
					Tracks.Add(new eQueryTypeAllTracks(zql, i));
				}
				foreach (var track in Tracks) {
					wtr.WriteLine();
					DumpObj(wtr, track);
				}
				wtr.Close();
			}
		}

//---------------------------------------------------------------------------------------

		// TODO: Take StreamWriter parm, defaults to null which creates the file.
		//		 Or something like that, that can let us dump the Zune data into a
		//		 single file
		private void DumpZuneItemsViaClass<QueryType>(
						ZuneLibrary zl,
						string Filename) where QueryType : class {
			IEnumerable<QueryType> Items = ZuneTypeFactory.GetZuneItems<QueryType>(zl);
			StreamWriter wtr = new StreamWriter(Filename);
			foreach (var item in Items) {
				wtr.WriteLine();
				DumpObj(wtr, item);
			}
			wtr.Close();
		}

//---------------------------------------------------------------------------------------

		private void DumpAllZune_Click(object sender, EventArgs e) {
			// TODO: Make this a method of ZuneTypeFactory
			// TODO: Sort and group by category (Albums, Photos, etc)
			DumpZuneItemsViaClass<eQueryTypeAllVideos>(zl, "LRS_Zune_Videos.txt");
			DumpZuneItemsViaClass<eQueryTypeAllVideosDetailed>(zl, "LRS_Zune_Videos_Detailed.txt");
			DumpZuneItemsViaClass<eQueryTypeAllTracksDetailed>(zl, "LRS_Zune_Tracks_Detailed.txt");
			DumpZuneItemsViaClass<eQueryTypeVideosByFolderId>(zl, "LRS_Zune_Videos_By_Folder_ID.txt");

			DumpZuneItemsViaClass<eQueryTypeAllPhotos>(zl, "LRS_Zune_Photos.txt");
			DumpZuneItemsViaClass<eQueryTypePhotosByFolderId>(zl, "LRS_Zune_Photos_By_Folder_ID.txt");

			DumpZuneItemsViaClass<eQueryTypeAllAlbums>(zl, "LRS_Zune_Albums.txt");
			DumpZuneItemsViaClass<eQueryTypeAllAlbumArtists>(zl, "LRS_Zune_Album_Artists.txt");
			DumpZuneItemsViaClass<eQueryTypeAlbumsForAlbumArtistId>(zl, "LRS_Zune_Album_Artist_ID.txt");
			DumpZuneItemsViaClass<eQueryTypeAlbumsForContributingArtistId>(zl, "LRS_Zune_Contributing_Artist_ID.txt");
			DumpZuneItemsViaClass<eQueryTypeAlbumsByTOC>(zl, "LRS_Zune_Albums_By_TOC.txt");

			DumpZuneItemsViaClass<eQueryTypeTracksForAlbumId>(zl, "LRS_Zune_Tracks_For_Album_ID.txt");
			DumpZuneItemsViaClass<eQueryTypeTracksForAlbumArtistId>(zl, "LRS_Zune_Tracks_For_Album_Artist_ID.txt");

			DumpZuneItemsViaClass<eQueryTypeAllPodcastSeries>(zl, "LRS_Zune_Podcast_Series.txt");
			DumpZuneItemsViaClass<eQueryTypeAllPodcastEpisodes>(zl, "LRS_Zune_Podcast_Episodes.txt");

			// TODO: More grouping
			DumpZuneItemsViaClass<eQueryTypeEpisodesForSeriesId>(zl, "LRS_Zune_Episodes_For_Series_ID.txt");
			DumpZuneItemsViaClass<eQueryTypeAlbumsWithKeyword>(zl, "LRS_Zune_Albums_With_Keyword.txt");
			DumpZuneItemsViaClass<eQueryTypeArtistsWithKeyword>(zl, "LRS_Zune_Artists_With_Keyword.txt");
			DumpZuneItemsViaClass<eQueryTypePhotosWithKeyword>(zl, "LRS_Zune_Photos_With_Keyword.txt");
			DumpZuneItemsViaClass<eQueryTypeSubscriptionsSeriesWithKeyword>(zl, "LRS_Zune_Subscriptions_Series_With_Keyword.txt");
			DumpZuneItemsViaClass<eQueryTypeSubscriptionsEpisodesWithKeyword>(zl, "LRS_Zune_Subscriptions_Episodes_With_Keyword.txt");
			DumpZuneItemsViaClass<eQueryTypeVideoWithKeyword>(zl, "LRS_Zune_Video_With_Keyword.txt");

			DumpZuneItemsViaClass<eQueryTypeMediaFolders>(zl, "LRS_Zune_Media_Folders.txt");
			DumpZuneItemsViaClass<eQueryTypeSyncProgress>(zl, "LRS_Zune_Sync_Progress.txt");

			DumpZuneItemsViaClass<eQueryTypeAllPlaylists>(zl, "LRS_Zune_Playlists.txt");
			DumpZuneItemsViaClass<eQueryTypePlaylistContentByPlaylistId>(zl, "LRS_Zune_Playlist_Contents_By_Playlist_ID.txt");

			DumpZuneItemsViaClass<eQueryTypeAllGenres>(zl, "LRS_Zune_Genres.txt");
			DumpZuneItemsViaClass<eQueryTypeTracksForGenreId>(zl, "LRS_Zune_Tracks_For_Genre_ID.txt");

			DumpZuneItemsViaClass<eQueryTypeTracksWithKeyword>(zl, "LRS_Zune_Tracks_With_Keyword.txt");
			DumpZuneItemsViaClass<eQueryTypeAllTracks>(zl, "LRS_Zune_Tracks.txt");
		}

//---------------------------------------------------------------------------------------

		private void btnGetVideosViaClasses_Click(object sender, EventArgs e) {
			StreamWriter wtr = new StreamWriter("LRSZune_Videos.txt");
			var Vids = ZuneTypeFactory.GetZuneItems<eQueryTypeAllVideos>(zl);
			foreach (var vid in Vids) {
				if (vid == null) {
					MessageBox.Show("Unable to get Videos data", "Zune2");
					return;
				}
				wtr.WriteLine();
				DumpObj(wtr, vid);
			}
			wtr.Close();
		}

//---------------------------------------------------------------------------------------

		private void btnVideosToXml_Click(object sender, EventArgs e) {
#if true
			XDocument xd = ZuneToXml<eQueryTypeAllVideos>(zl, "LRSZuneVideos", "Video");
			xd.Save("LRS_Videos.xml");
#else
			var Vids = ZuneTypeFactory.GetZuneItems<eQueryTypeAllVideos>(zl);
			XDocument xd = new XDocument(
				new XElement("ZuneVideos",
					from item in Vids
					select new XElement("Video", 
						from vid in item.GetType().GetFields()
							select new XElement("Field", 
								new XAttribute("Name", vid.Name),
								new XAttribute("Type", MapTypeToCSharp(vid.FieldType.ToString(), false)),
								vid.GetValue(item))
						)
				)
			);
			xd.Save("LRS_Videos.xml");
#endif
		}

//---------------------------------------------------------------------------------------

		private XDocument ZuneToXml<QueryType>(
				ZuneLibrary zl, 
				string		TopElementName, 
				string		ElementName) where QueryType : class {
			var ZuneItems = ZuneTypeFactory.GetZuneItems<QueryType>(zl);
			XDocument xd = new XDocument(
				new XElement(TopElementName,
					from item in ZuneItems
					select new XElement(ElementName, 
						from Item in item.GetType().GetFields()
							select new XElement("Field", 
								new XAttribute("Name", Item.Name),
								new XAttribute("Type", MapTypeToCSharp(Item.FieldType.ToString(), false)),
								Item.GetValue(item))
						)
				)
			);
			return xd;
		}

//---------------------------------------------------------------------------------------

		private void btnAlbumsToXml_Click(object sender, EventArgs e) {
			XDocument xd = ZuneToXml<eQueryTypeAllAlbums>(zl, "LRSZuneAlbums", "Album");
			xd.Save("LRS_Albums.xml");
		}

//---------------------------------------------------------------------------------------

		private void btnTracksToXml_Click(object sender, EventArgs e) {
			XDocument xd = ZuneToXml<eQueryTypeAllTracks>(zl, "LRSZuneTracks", "Track");
			xd.Save("LRS_Tracks.xml");
		}
	}


//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------

	internal class SchemaMapAndType {
		internal SchemaMap	smt;
		internal Type		type;

//---------------------------------------------------------------------------------------

		internal SchemaMapAndType(SchemaMap smt, Type type) {
			this.smt  = smt;
			this.type = type;
		}
	}
}