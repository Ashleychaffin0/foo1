﻿using System;

namespace LrsColinAssembler {
	internal partial class Interpreter {

//---------------------------------------------------------------------------------------

		/// <summary>
		/// Starts tracing
		/// </summary>
		private void Exec_TraceOn() {                 // 0xFA
			Tracing = true;
			++PC;
		}

//---------------------------------------------------------------------------------------

		/// <summary>
		/// Stops tracing
		/// </summary>
		private void Exec_TraceOff() {                 // 0xFB
			Tracing = false;										
			++PC;
		}

//---------------------------------------------------------------------------------------

		/// <summary>
		/// Displays the contents of a register
		/// </summary>
		private void Exec_PREG() {                  // 0xFC
			LastOpWasPrint = true;
			byte Reg = Ram[PC + 1];
			Console.Write(Registers[Reg]);
			PC += 2;
		}

//---------------------------------------------------------------------------------------

		/// <summary>
		/// Displays the contents of a numeric field in memory
		/// </summary>
		private void Exec_PNUM() {                  // 0xFD
			LastOpWasPrint = true;
			short addr = DecodeAddress(PC + 1);
			Console.Write(Word(addr));
			PC += 4;
		}

//---------------------------------------------------------------------------------------

		/// <summary>
		/// Displays the contents of a string in memory
		/// </summary>
		private void Exec_PSTRING() {               // 0xFE
			short addr = DecodeAddress(PC + 2);
			LastOpWasPrint = true;
			while (true) {
				byte b = Ram[addr++];
				if (b == 0) { break; }
				Console.Write((char)b);
			}
			PC += 4;
		}

//---------------------------------------------------------------------------------------

		/// <summary>
		/// Stops execution of the program
		/// </summary>
		private void Exec_STOP() => IsRunning = false;	// 0xFF
	}
}
