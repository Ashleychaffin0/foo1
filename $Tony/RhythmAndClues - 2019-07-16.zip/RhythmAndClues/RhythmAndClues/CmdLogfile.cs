﻿namespace RhythmAndClues {
	// Note: This class not currently used
	internal class CmdLogfile : ICommand {
		private Interpreter main;

//---------------------------------------------------------------------------------------

		public CmdLogfile(Interpreter main) => this.main = main;

//---------------------------------------------------------------------------------------

		public bool CheckSyntax(string[] tokens) {
			var filename = main.GetFilename(tokens);
			return false;
		}

//---------------------------------------------------------------------------------------

		public bool Execute(string[] tokens) {
			return false;
		}
	}
}