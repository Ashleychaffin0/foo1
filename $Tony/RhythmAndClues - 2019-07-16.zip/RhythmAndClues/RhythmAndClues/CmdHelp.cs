﻿namespace RhythmAndClues {
	// The HELP command
	class CmdHelp : ICommand {
		readonly Interpreter main;

//---------------------------------------------------------------------------------------

		public CmdHelp(Interpreter main) => this.main = main;

//---------------------------------------------------------------------------------------

		public bool CheckSyntax(string[] tokens) {
			if (tokens.Length > 1) {
				main.SyntaxError("The HELP command takes no parameters");
				return false;
			}
			return true;
		}

//---------------------------------------------------------------------------------------

		public bool Execute(string[] tokens) {
			main.Msg("The valid commands are:");
			main.Msg("\tPATH (<foldername> | <emtpy>");
			main.Msg("\t\tIf <empty>, uses environment variable RACPath, if present");
			main.Msg("\tLOGFILE <filename>");
			main.Msg("\tLoad-Notes <filename>");
			main.Msg("\tLoad-Pattern <filename>");
			main.Msg("\tApply-Rhythm/AR");
			main.Msg("\tDump-Measures (SCORE | PATTERN | empty)");
			main.Msg("\t\tThe default is SCORE");
			main.Msg("\tSave <filename>");
			main.Msg();
			main.Msg("All commands and parameters are case-insensitive, except perhaps filenames");
			return true;
		}
	}
}
