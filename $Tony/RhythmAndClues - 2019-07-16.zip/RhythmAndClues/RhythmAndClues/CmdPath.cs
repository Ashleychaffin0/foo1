﻿using System;
using System.IO;

namespace RhythmAndClues {
	internal class CmdPath : ICommand {
		private Interpreter main;

//---------------------------------------------------------------------------------------

		public CmdPath(Interpreter main) => this.main = main;

//---------------------------------------------------------------------------------------

		public bool CheckSyntax(string[] tokens) {
			string path;
			switch (tokens.Length) {
			case 1:						// No arguments given
				path = Environment.GetEnvironmentVariable("RACPath");
				if (path is null) {
					main.SyntaxError("No RACPath environment variable found");
					return false;
				}
				if (! Directory.Exists(path)) {
					main.SyntaxError($"Path '{path}' from RACPath does not exist");
					return false;
				}
				main.CurrentPath = path;
				break;
			default:
				var dirname = main.JoinParms(tokens);
				if (! Directory.Exists(dirname)) {
					main.SyntaxError($"Path '{dirname}' does not exist");
					return false;
				}
				// main.SyntaxError("No more than 1 argument to the PATH command");
				main.CurrentPath = dirname;
				break;
			}
			return true;
		}

//---------------------------------------------------------------------------------------

		public bool Execute(string[] tokens) {
			// Nothing to do here. Everything's done in CheckSyntax
			return true;
		}
	}
}