﻿namespace RhythmAndClues {
	internal class CmdDebugPrint : ICommand {
		readonly Interpreter main;

		public CmdDebugPrint(Interpreter main) => this.main = main;

//---------------------------------------------------------------------------------------

		public bool CheckSyntax(string[] tokens) => true;

//---------------------------------------------------------------------------------------

		public bool Execute(string[] tokens) {
			string msg = main.JoinParms(tokens);
			main.Msg(msg);
			return true;
		}
	}
}