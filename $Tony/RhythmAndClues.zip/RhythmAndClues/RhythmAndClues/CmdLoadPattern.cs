﻿using System.IO;

namespace RhythmAndClues {
	internal class CmdLoadPattern : ICommand {
		private Interpreter main;

//---------------------------------------------------------------------------------------

		public CmdLoadPattern(Interpreter main) => this.main = main;

//---------------------------------------------------------------------------------------

		public bool CheckSyntax(string[] tokens) {
			bool retval = true;
			if (tokens.Length == 1) {
				main.SyntaxError("Syntax: LOAD-PATTERN <filename>");
				retval = false;
			}

			main.PatternFilename = main.GetFilename(tokens);
			if (File.Exists(main.PatternFilename)) {
				main.bLoadPatternFound = true;
			} else {
				main.SyntaxError($"Input file does not exist: {main.PatternFilename}");
				retval = false;
			}
			return retval;
		}

//---------------------------------------------------------------------------------------

		public bool Execute(string[] tokens) {
			main.XmlPattern      = new MusicXml(main.PatternFilename);
			return true;
		}
	}
}
