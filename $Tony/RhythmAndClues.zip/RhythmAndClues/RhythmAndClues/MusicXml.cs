﻿using System.IO;
using System.Xml;

namespace RhythmAndClues {
	class MusicXml {
		internal string			filename;
		internal XmlDocument	xdoc;
		internal XmlNodeList	Measures;

//---------------------------------------------------------------------------------------

		public MusicXml(string filename) {
			this.filename = filename;

			xdoc = new XmlDocument();
			string xml = File.ReadAllText(filename);
#if false
			if (bReplaceRests) {
				xml = xml.Replace("<rest />", "<rest/>").Replace("<rest/>", @"<pitch>
		  <step>A</step>
		  <octave>4</octave>
		  </pitch>");
			}
#endif
			xdoc.LoadXml(xml);

			Measures = GetMeasures();
		}

//---------------------------------------------------------------------------------------

		internal XmlNodeList GetMeasures() => xdoc.GetElementsByTagName("measure");

//---------------------------------------------------------------------------------------

		internal XmlNodeList GetNotes() => xdoc.GetElementsByTagName("note");

//---------------------------------------------------------------------------------------

		public void Save(string filename) {
			xdoc.Save(filename);
		}
	}
}
