﻿using System;
using System.Xml;

namespace RhythmAndClues {
	class CmdDumpMeasures : ICommand {
		readonly Interpreter main;

		//---------------------------------------------------------------------------------------

		public CmdDumpMeasures(Interpreter main) => this.main = main;

		//---------------------------------------------------------------------------------------

		public bool CheckSyntax(string[] tokens) {
			switch (tokens.Length) {
			case 1:             // No parm -- default to Pattern
				main.MeasurePattern = main.XmlScore;
				main.Msg("Defaulting to SCORE");
				break;
			case 2:
				string id = tokens[1].ToUpper();
				switch (id) {
				case "PATTERN":
					main.MeasurePattern = main.XmlPattern;
					break;
				case "SCORE":
					main.MeasurePattern = main.XmlScore;
					break;
				default:
					main.SyntaxError("DUMP-MEASURES parameter must be (SCORE | PATTERN | empty");
					return false;
				}
				break;
			default:
				main.SyntaxError("DUMP-MEASURES takes 0 or 1 parameters. See HELP");
				return false;
			}
			return true;
		}

//---------------------------------------------------------------------------------------

		public bool Execute(string[] tokens) {
			MusicXml measures;
			if (tokens.Length == 1) {
				measures = main.XmlScore;		// Set default
			} else {
				measures = tokens[1].ToUpper() == "SCORE" ? main.XmlScore : main.XmlPattern;
			}
			foreach (XmlElement meas in measures.GetMeasures()) {
				// A bunch of messing around just to make things look pretty
				int MeasNumWidth = (int)(Math.Ceiling(Math.Log10(main.XmlScore.Measures.Count)));
				MeasNumWidth += "Measure[]".Length + 3; // 4 -> subscripts up to 999
				string num = meas.GetAttribute("number");
				main.Msg();
				string MeasureText = $"Measure[{num}]".PadRight(MeasNumWidth);
				int n = 0;
				string hdr = $"{MeasureText} Pitch  Duration     Type";
				main.Msg("".PadLeft(hdr.Length, '='));
				main.Msg(hdr);
				main.Msg("               -----  --------  -------");
				foreach (XmlElement note in meas.GetElementsByTagName("note")) {
					string subN = $"  [{++n}]".PadRight(6);
					var pitchElem   = main.GetFirstElement(note, "pitch");
					var dur         = main.GetFirstElement(note, "duration");
					string duration = (dur is null ? "N/A" : dur.InnerText).PadLeft(8);
					string pitch    = " rest";       // Probably not, but just in case
					string type     = "  rest";
					if (!(pitchElem is null)) {       // Check for a non-rest
						pitch = pitchElem.InnerText.PadLeft(5);
						type = main.GetFirstElement(note, "type").InnerText.PadLeft(6);
					}
					main.Msg($" {subN}        {pitch}  {duration}   {type}");
				}
			}
			return true;
		}
	}
}
